package br.com.asd;

public class Main {
    public static void main(String[] args) {
        ThreadMestra mestra = new ThreadMestra();
        mestra.start();
    }


}